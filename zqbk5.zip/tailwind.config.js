module.exports = {
  purge: [],
  darkMode: false, // or 'media' or 'class'
  theme: {
    extend: {
      colors: {
        verde: "#00b164",
        gris: "#393939"
      }
    }
  },
  variants: {},
  plugins: []
};
